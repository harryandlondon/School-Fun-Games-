"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft } from "lucide-react"

interface Employee {
  id: string
  name: string
  password: string
  lastLogin?: string
}

export default function CheckPasswordPage() {
  const [password, setPassword] = useState("")
  const [result, setResult] = useState<string | null>(null)
  const [employees, setEmployees] = useState<Employee[]>([])
  const router = useRouter()

  useEffect(() => {
    // Load employees from localStorage
    const storedEmployees = localStorage.getItem("employees")
    if (storedEmployees) {
      setEmployees(JSON.parse(storedEmployees))
    }
  }, [])

  const checkPassword = () => {
    if (!password) {
      setResult("Please enter a password")
      return
    }

    // Check if it's the master password
    if (password === "London0801") {
      sessionStorage.setItem("isAuthenticated", "true")
      sessionStorage.setItem("isMasterAdmin", "true")
      router.push("/admin")
      return
    }

    const employee = employees.find((emp) => emp.password === password)

    if (employee) {
      // Record login time
      const updatedEmployees = employees.map((emp) =>
        emp.id === employee.id ? { ...emp, lastLogin: new Date().toLocaleString() } : emp,
      )

      setEmployees(updatedEmployees)
      localStorage.setItem("employees", JSON.stringify(updatedEmployees))

      // Store current employee in session storage
      sessionStorage.setItem("isAuthenticated", "true")
      sessionStorage.setItem("isMasterAdmin", "false")
      sessionStorage.setItem("currentEmployee", JSON.stringify(employee))

      router.push("/admin") // Now regular employees go to admin too, but with limited access
    } else {
      setResult("Invalid password. Access denied.")
    }
  }

  return (
    <div className="min-h-screen bg-[#f0f8ff] flex flex-col">
      <header className="bg-[#4169e1] text-white text-center p-5 border-b-8 border-[#ffd700] relative">
        <h1 className="text-4xl font-bold m-0 font-comic text-shadow">🎮 School Fun Games 🎮</h1>
        <div className="absolute top-2 left-2">
          <Button variant="ghost" className="text-white hover:bg-blue-700" onClick={() => router.push("/")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Games
          </Button>
        </div>
      </header>

      <div className="container mx-auto py-8 px-4 flex-grow flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle>Staff Login</CardTitle>
            <CardDescription>Enter your password to access staff features</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  checkPassword()
                }
              }}
            />

            {result && (
              <Alert
                className={
                  result.includes("Access granted")
                    ? "bg-green-50 border-green-200"
                    : result.includes("Invalid")
                      ? "bg-red-50 border-red-200"
                      : "bg-blue-50 border-blue-200"
                }
              >
                <AlertDescription>{result}</AlertDescription>
              </Alert>
            )}
          </CardContent>
          <CardFooter>
            <Button onClick={checkPassword} className="w-full">
              Login
            </Button>
          </CardFooter>
        </Card>
      </div>

      <footer className="bg-[#4169e1] text-white text-center p-4 border-t-8 border-[#ffd700]">
        <p>© {new Date().getFullYear()} School Fun Games | Created for educational purposes</p>
      </footer>
    </div>
  )
}

