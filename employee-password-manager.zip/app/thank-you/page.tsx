"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, ThumbsUp, Heart, User, Quote } from "lucide-react"

interface ThankYouMessage {
  id: string
  name: string
  message: string
  date: string
}

export default function ThankYouPage() {
  const [name, setName] = useState<string>("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [thankYouMessages, setThankYouMessages] = useState<ThankYouMessage[]>([])
  const router = useRouter()

  useEffect(() => {
    // Check if user is authenticated (optional now)
    const isAuth = sessionStorage.getItem("isAuthenticated")
    if (isAuth === "true") {
      setIsAuthenticated(true)

      // Get employee name if available
      const employeeData = sessionStorage.getItem("currentEmployee")
      if (employeeData) {
        const employee = JSON.parse(employeeData)
        setName(employee.name)
      } else if (sessionStorage.getItem("isMasterAdmin") === "true") {
        setName("Administrator")
      }
    }

    // Load thank you messages
    const storedThankYouMessages = localStorage.getItem("thankYouMessages")
    if (storedThankYouMessages) {
      setThankYouMessages(JSON.parse(storedThankYouMessages))
    }
  }, [])

  return (
    <div className="min-h-screen bg-[#f0f8ff] flex flex-col">
      <header className="bg-[#4169e1] text-white text-center p-5 border-b-8 border-[#ffd700] relative">
        <h1 className="text-4xl font-bold m-0 font-comic text-shadow">🎮 School Fun Games 🎮</h1>
        <div className="absolute top-2 left-2">
          <Button
            variant="ghost"
            className="text-white hover:bg-blue-700"
            onClick={() => (isAuthenticated ? router.push("/admin") : router.push("/"))}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            {isAuthenticated ? "Back to Dashboard" : "Back to Games"}
          </Button>
        </div>
      </header>

      <div className="container mx-auto py-12 px-4 flex-grow">
        <div className="max-w-4xl mx-auto">
          <Card className="mb-8">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 bg-green-100 p-3 rounded-full inline-block">
                <ThumbsUp className="h-12 w-12 text-green-600" />
              </div>
              <CardTitle className="text-3xl">Thank You!</CardTitle>
              <CardDescription className="text-lg">
                {name ? `Hello ${name}! ` : ""}
                Thank you for visiting School Fun Games.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p>School Fun Games provides educational games to students and makes learning more engaging and fun.</p>
              <div className="py-4 flex justify-center">
                <Heart className="h-8 w-8 text-red-500 animate-pulse" />
              </div>
              <p className="font-medium">We hope you enjoy the games and learn something new!</p>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button
                onClick={() => (isAuthenticated ? router.push("/admin") : router.push("/"))}
                className="bg-[#32cd32] hover:bg-[#228b22]"
              >
                {isAuthenticated ? "Return to Dashboard" : "Return to Games"}
              </Button>
            </CardFooter>
          </Card>

          {thankYouMessages.length > 0 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-center text-[#4169e1]">Special Thank You Messages</h2>
              <div className="grid gap-6 md:grid-cols-2">
                {thankYouMessages.map((message) => (
                  <Card key={message.id} className="bg-white border-2 border-[#ffd700]">
                    <CardHeader>
                      <div className="flex items-center gap-2">
                        <User className="h-5 w-5 text-[#4169e1]" />
                        <CardTitle className="text-xl">{message.name}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex">
                        <Quote className="h-6 w-6 text-[#ffd700] mr-2 flex-shrink-0" />
                        <p className="italic">{message.message}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <footer className="bg-[#4169e1] text-white text-center p-4 border-t-8 border-[#ffd700]">
        <p>© {new Date().getFullYear()} School Fun Games | Created for educational purposes</p>
      </footer>
    </div>
  )
}

