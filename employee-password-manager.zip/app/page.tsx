"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { AlertCircle, Lock, Heart } from "lucide-react"

interface Game {
  id: string
  title: string
  description: string
  emoji: string
  link: string
}

export default function HomePage() {
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [games, setGames] = useState<Game[]>([])
  const router = useRouter()

  useEffect(() => {
    // Load games from localStorage
    const savedGames = localStorage.getItem("schoolGames")
    if (savedGames) {
      try {
        setGames(JSON.parse(savedGames))
      } catch (e) {
        console.error("Could not parse saved games", e)
      }
    }
  }, [])

  const checkPassword = async () => {
    if (!password) return

    // First check if it's the master password
    if (password === "London0801") {
      sessionStorage.setItem("isAuthenticated", "true")
      sessionStorage.setItem("isMasterAdmin", "true")
      router.push("/admin")
      return
    }

    // Then check if it's an employee password
    const storedEmployees = localStorage.getItem("employees")
    if (storedEmployees) {
      const employees = JSON.parse(storedEmployees)
      const employee = employees.find((emp: any) => emp.password === password)

      if (employee) {
        // Record login time
        const updatedEmployees = employees.map((emp: any) =>
          emp.id === employee.id ? { ...emp, lastLogin: new Date().toLocaleString() } : emp,
        )

        localStorage.setItem("employees", JSON.stringify(updatedEmployees))
        sessionStorage.setItem("isAuthenticated", "true")
        sessionStorage.setItem("currentEmployee", JSON.stringify(employee))
        router.push("/admin")
        return
      }
    }

    setError("Invalid password")
    setTimeout(() => setError(""), 3000)
  }

  const handleReportGame = (gameId: string) => {
    // Redirect to login page if trying to report
    router.push("/check-password")
  }

  return (
    <div className="min-h-screen bg-[#f0f8ff]">
      <header className="bg-[#4169e1] text-white text-center p-5 border-b-8 border-[#ffd700] relative">
        <h1 className="text-4xl font-bold m-0 font-comic text-shadow">🎮 School Fun Games 🎮</h1>
        <div className="absolute top-2 right-2 flex items-center gap-2">
          <Button onClick={() => router.push("/thank-you")} className="bg-[#32cd32] hover:bg-[#228b22]">
            <Heart className="mr-2 h-4 w-4" /> Thank You
          </Button>
          <Button
            onClick={() => router.push("/check-password")}
            className="bg-[#ffd700] text-[#4169e1] hover:bg-[#ffd700]/80"
          >
            <Lock className="mr-2 h-4 w-4" /> Staff Login
          </Button>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 flex items-center">
            <AlertCircle className="h-5 w-5 mr-2" />
            {error}
          </div>
        )}

        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-[#4169e1]">Welcome to School Fun Games</h2>
          <p className="text-gray-600">Browse and play educational games</p>
        </div>

        {games.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {games.map((game) => (
              <Card key={game.id} className="overflow-hidden transition-transform hover:-translate-y-1">
                <div className="h-32 bg-[#ffd700] flex items-center justify-center text-5xl">{game.emoji}</div>
                <CardContent className="p-4">
                  <h3 className="text-xl font-bold text-[#4169e1]">{game.title}</h3>
                  <p className="text-gray-600 mt-2">{game.description}</p>
                  <div className="flex justify-between mt-4">
                    <a href={game.link} target="_blank" rel="noopener noreferrer">
                      <Button className="bg-[#32cd32] hover:bg-[#228b22]">Play Now</Button>
                    </a>
                    <Button onClick={() => handleReportGame(game.id)} className="bg-[#ff6b6b] hover:bg-[#ff4757]">
                      Report
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            <p className="text-xl">No games have been added yet.</p>
            <p>Staff members can add games after logging in.</p>
          </div>
        )}
      </main>

      <footer className="bg-[#4169e1] text-white text-center p-4 mt-8 border-t-8 border-[#ffd700]">
        <p>© {new Date().getFullYear()} School Fun Games | Created for educational purposes</p>
      </footer>
    </div>
  )
}

