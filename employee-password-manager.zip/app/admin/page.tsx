"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { PlusCircle, Trash2, Eye, EyeOff, Plus, X, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface Employee {
  id: string
  name: string
  password: string
  lastLogin?: string
}

interface Game {
  id: string
  title: string
  description: string
  emoji: string
  link: string
}

interface Notification {
  id: string
  gameTitle: string
  gameId: string
  reason: string
  details: string
  date: string
  dismissed: boolean
}

interface ThankYouMessage {
  id: string
  name: string
  message: string
  date: string
}

export default function AdminPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [employees, setEmployees] = useState<Employee[]>([])
  const [games, setGames] = useState<Game[]>([])
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [thankYouMessages, setThankYouMessages] = useState<ThankYouMessage[]>([])
  const [newEmployee, setNewEmployee] = useState<Omit<Employee, "id">>({ name: "", password: "" })
  const [newGame, setNewGame] = useState<Omit<Game, "id">>({
    title: "",
    description: "",
    emoji: "🎮",
    link: "",
  })
  const [newThankYou, setNewThankYou] = useState<Omit<ThankYouMessage, "id" | "date">>({
    name: "",
    message: "",
  })
  const [showPasswords, setShowPasswords] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [addGameFormVisible, setAddGameFormVisible] = useState(false)
  const [addThankYouFormVisible, setAddThankYouFormVisible] = useState(false)

  // Check if user is authenticated
  useEffect(() => {
    const checkAuth = () => {
      const isAuth = sessionStorage.getItem("isAuthenticated")

      if (isAuth === "true") {
        setIsAuthenticated(true)
        // isMasterAdmin is already set in sessionStorage, no need to check here
      } else {
        router.push("/")
      }
    }

    checkAuth()

    // Load data from localStorage
    loadData()
  }, [router])

  const loadData = () => {
    // Load employees
    const storedEmployees = localStorage.getItem("employees")
    if (storedEmployees) {
      setEmployees(JSON.parse(storedEmployees))
    }

    // Load games
    const storedGames = localStorage.getItem("schoolGames")
    if (storedGames) {
      setGames(JSON.parse(storedGames))
    }

    // Load notifications
    const storedNotifications = localStorage.getItem("gameNotifications")
    if (storedNotifications) {
      setNotifications(JSON.parse(storedNotifications))
    }

    // Load thank you messages
    const storedThankYouMessages = localStorage.getItem("thankYouMessages")
    if (storedThankYouMessages) {
      setThankYouMessages(JSON.parse(storedThankYouMessages))
    }
  }

  // Save data to localStorage
  const saveEmployees = (data: Employee[]) => {
    localStorage.setItem("employees", JSON.stringify(data))
    setEmployees(data)
  }

  const saveGames = (data: Game[]) => {
    localStorage.setItem("schoolGames", JSON.stringify(data))
    setGames(data)
  }

  const saveNotifications = (data: Notification[]) => {
    localStorage.setItem("gameNotifications", JSON.stringify(data))
    setNotifications(data)
  }

  const saveThankYouMessages = (data: ThankYouMessage[]) => {
    localStorage.setItem("thankYouMessages", JSON.stringify(data))
    setThankYouMessages(data)
  }

  // Add a new employee
  const addEmployee = () => {
    if (!newEmployee.name || !newEmployee.password) {
      setError("Please enter both name and password")
      return
    }

    // Check if employee name already exists
    if (employees.some((emp) => emp.name.toLowerCase() === newEmployee.name.toLowerCase())) {
      setError("An employee with this name already exists")
      return
    }

    const employee: Employee = {
      id: Date.now().toString(),
      name: newEmployee.name,
      password: newEmployee.password,
    }

    const updatedEmployees = [...employees, employee]
    saveEmployees(updatedEmployees)
    setNewEmployee({ name: "", password: "" })
    setSuccess("Employee added successfully")
    setTimeout(() => setSuccess(""), 3000)
    setError("")
  }

  // Delete an employee
  const deleteEmployee = (id: string) => {
    const updatedEmployees = employees.filter((emp) => emp.id !== id)
    saveEmployees(updatedEmployees)
    setSuccess("Employee removed successfully")
    setTimeout(() => setSuccess(""), 3000)
  }

  // Generate a random password
  const generatePassword = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*"
    let password = ""
    for (let i = 0; i < 10; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setNewEmployee({ ...newEmployee, password })
  }

  // Add a new game
  const addGame = () => {
    if (!newGame.title || !newGame.description || !newGame.link) {
      setError("Please fill in all game fields")
      return
    }

    const game: Game = {
      id: Date.now().toString(),
      title: newGame.title,
      description: newGame.description,
      emoji: newGame.emoji,
      link: newGame.link,
    }

    const updatedGames = [...games, game]
    saveGames(updatedGames)
    setNewGame({ title: "", description: "", emoji: "🎮", link: "" })
    setSuccess("Game added successfully")
    setTimeout(() => setSuccess(""), 3000)
    setError("")
    setAddGameFormVisible(false)
  }

  // Delete a game
  const deleteGame = (id: string) => {
    const updatedGames = games.filter((game) => game.id !== id)
    saveGames(updatedGames)

    // Also remove any notifications for this game
    const updatedNotifications = notifications.filter((n) => n.gameId !== id)
    saveNotifications(updatedNotifications)

    setSuccess("Game removed successfully")
    setTimeout(() => setSuccess(""), 3000)
  }

  // Add a new thank you message
  const addThankYouMessage = () => {
    if (!newThankYou.name || !newThankYou.message) {
      setError("Please enter both name and message")
      return
    }

    const thankYouMessage: ThankYouMessage = {
      id: Date.now().toString(),
      name: newThankYou.name,
      message: newThankYou.message,
      date: new Date().toLocaleString(),
    }

    const updatedMessages = [...thankYouMessages, thankYouMessage]
    saveThankYouMessages(updatedMessages)
    setNewThankYou({ name: "", message: "" })
    setSuccess("Thank you message added successfully")
    setTimeout(() => setSuccess(""), 3000)
    setError("")
    setAddThankYouFormVisible(false)
  }

  // Delete a thank you message
  const deleteThankYouMessage = (id: string) => {
    const updatedMessages = thankYouMessages.filter((msg) => msg.id !== id)
    saveThankYouMessages(updatedMessages)
    setSuccess("Thank you message removed successfully")
    setTimeout(() => setSuccess(""), 3000)
  }

  // Dismiss a notification
  const dismissNotification = (id: string) => {
    const updatedNotifications = notifications.map((n) => (n.id === id ? { ...n, dismissed: true } : n))
    saveNotifications(updatedNotifications)
    setSuccess("Notification dismissed")
    setTimeout(() => setSuccess(""), 3000)
  }

  // Clear all games
  const clearAllGames = () => {
    if (confirm("Are you sure you want to delete all games?")) {
      saveGames([])
      saveNotifications([])
      setSuccess("All games cleared")
      setTimeout(() => setSuccess(""), 3000)
    }
  }

  // Logout
  const logout = () => {
    sessionStorage.removeItem("isAuthenticated")
    sessionStorage.removeItem("isMasterAdmin")
    router.push("/")
  }

  // Count active notifications
  const activeNotificationsCount = notifications.filter((n) => !n.dismissed).length

  return (
    <div className="min-h-screen bg-[#f0f8ff]">
      <header className="bg-[#4169e1] text-white text-center p-5 border-b-8 border-[#ffd700] relative">
        <h1 className="text-4xl font-bold m-0 font-comic text-shadow">🎮 School Fun Games Admin 🎮</h1>
        <div className="absolute top-2 right-2 flex gap-2">
          <Button onClick={() => router.push("/thank-you")} className="bg-[#32cd32] hover:bg-[#228b22]">
            Thank You Page
          </Button>
          <Button onClick={logout} className="bg-[#ffd700] text-[#4169e1] hover:bg-[#ffd700]/80">
            Logout
          </Button>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        {success && (
          <Alert className="bg-green-50 border-green-200 mb-4">
            <AlertTitle>Success</AlertTitle>
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="games" className="w-full">
          <TabsList className="grid grid-cols-4 mb-8">
            <TabsTrigger value="games">Games Management</TabsTrigger>
            {sessionStorage.getItem("isMasterAdmin") === "true" && (
              <TabsTrigger value="employees">Employee Passwords</TabsTrigger>
            )}
            <TabsTrigger value="notifications" className="relative">
              Notifications
              {activeNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  {activeNotificationsCount}
                </span>
              )}
            </TabsTrigger>
            {sessionStorage.getItem("isMasterAdmin") === "true" && (
              <TabsTrigger value="thank-you-list">
                <Heart className="mr-2 h-4 w-4" /> Thank You List
              </TabsTrigger>
            )}
          </TabsList>

          {/* Games Management Tab */}
          <TabsContent value="games" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-[#4169e1]">Games Management</h2>
              <div className="space-x-2">
                <Button
                  onClick={() => setAddGameFormVisible(!addGameFormVisible)}
                  className="bg-[#32cd32] hover:bg-[#228b22]"
                >
                  {addGameFormVisible ? <X className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
                  {addGameFormVisible ? "Cancel" : "Add Game"}
                </Button>
                <Button onClick={clearAllGames} variant="destructive">
                  Clear All Games
                </Button>
              </div>
            </div>

            {addGameFormVisible && (
              <Card>
                <CardHeader>
                  <CardTitle>Add New Game</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Game Title:</label>
                        <Input
                          value={newGame.title}
                          onChange={(e) => setNewGame({ ...newGame, title: e.target.value })}
                          placeholder="Enter game title"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Choose an Emoji:</label>
                        <Select
                          value={newGame.emoji}
                          onValueChange={(value) => setNewGame({ ...newGame, emoji: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select emoji" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="🎮">🎮 Game Controller</SelectItem>
                            <SelectItem value="🧩">🧩 Puzzle</SelectItem>
                            <SelectItem value="🎯">🎯 Target</SelectItem>
                            <SelectItem value="🎲">🎲 Dice</SelectItem>
                            <SelectItem value="🎨">🎨 Art</SelectItem>
                            <SelectItem value="🔢">🔢 Math</SelectItem>
                            <SelectItem value="📚">📚 Reading</SelectItem>
                            <SelectItem value="🌍">🌍 Geography</SelectItem>
                            <SelectItem value="🏀">🏀 Sports</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Game Description:</label>
                      <Textarea
                        value={newGame.description}
                        onChange={(e) => setNewGame({ ...newGame, description: e.target.value })}
                        placeholder="Describe the game"
                        rows={3}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Game Link:</label>
                      <Input
                        type="url"
                        value={newGame.link}
                        onChange={(e) => setNewGame({ ...newGame, link: e.target.value })}
                        placeholder="https://example.com/game"
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end space-x-2">
                  <Button onClick={addGame} className="bg-[#32cd32] hover:bg-[#228b22]">
                    Add Game
                  </Button>
                </CardFooter>
              </Card>
            )}

            {games.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {games.map((game) => (
                  <Card key={game.id} className="overflow-hidden">
                    <div className="h-32 bg-[#ffd700] flex items-center justify-center text-5xl">{game.emoji}</div>
                    <CardContent className="p-4">
                      <h3 className="text-xl font-bold text-[#4169e1]">{game.title}</h3>
                      <p className="text-gray-600 mt-2">{game.description}</p>
                      <div className="flex justify-between mt-4">
                        <a href={game.link} target="_blank" rel="noopener noreferrer">
                          <Button className="bg-[#32cd32] hover:bg-[#228b22]">Play Now</Button>
                        </a>
                        <Button onClick={() => deleteGame(game.id)} variant="destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-white rounded-lg shadow">
                <p className="text-xl text-gray-500">No games have been added yet.</p>
                <p className="text-gray-400">Click "Add Game" to create your first game.</p>
              </div>
            )}
          </TabsContent>

          {/* Employee Passwords Tab */}
          <TabsContent value="employees" className="space-y-6">
            {sessionStorage.getItem("isMasterAdmin") === "true" ? (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle>Employee Password Management</CardTitle>
                    <CardDescription>Create and manage passwords for each employee</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <Input
                          placeholder="Employee Name"
                          value={newEmployee.name}
                          onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })}
                        />
                      </div>
                      <div className="flex space-x-2">
                        <Input
                          type={showPasswords ? "text" : "password"}
                          placeholder="Password"
                          value={newEmployee.password}
                          onChange={(e) => setNewEmployee({ ...newEmployee, password: e.target.value })}
                        />
                        <Button variant="outline" size="icon" onClick={() => setShowPasswords(!showPasswords)}>
                          {showPasswords ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={generatePassword}>
                      Generate Password
                    </Button>
                    <Button onClick={addEmployee}>
                      <PlusCircle className="mr-2 h-4 w-4" /> Add Employee
                    </Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle>Employee List</CardTitle>
                      <Button variant="outline" size="sm" onClick={() => setShowPasswords(!showPasswords)}>
                        {showPasswords ? "Hide Passwords" : "Show Passwords"}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {employees.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Password</TableHead>
                            <TableHead>Last Login</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {employees.map((employee) => (
                            <TableRow key={employee.id}>
                              <TableCell>{employee.name}</TableCell>
                              <TableCell>{showPasswords ? employee.password : "••••••••••"}</TableCell>
                              <TableCell>{employee.lastLogin || "Never"}</TableCell>
                              <TableCell>
                                <Button variant="destructive" size="sm" onClick={() => deleteEmployee(employee.id)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-center py-4 text-muted-foreground">No employees added yet</div>
                    )}
                  </CardContent>
                </Card>
              </>
            ) : (
              <div className="text-center py-12 bg-white rounded-lg shadow">
                <p className="text-xl text-red-500">Access Denied</p>
                <p className="text-gray-500 mt-2">Only the master administrator can access employee management.</p>
              </div>
            )}
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Reported Games</CardTitle>
                <CardDescription>Review and manage reports submitted by users</CardDescription>
              </CardHeader>
              <CardContent>
                {notifications.filter((n) => !n.dismissed).length > 0 ? (
                  <div className="space-y-4">
                    {notifications
                      .filter((n) => !n.dismissed)
                      .map((notification) => (
                        <div key={notification.id} className="p-4 border-l-4 border-red-500 bg-red-50 rounded">
                          <div className="font-bold text-red-600">Game "{notification.gameTitle}" was reported</div>
                          <div>Reason: {notification.reason}</div>
                          {notification.details && <div>Details: {notification.details}</div>}
                          <div className="text-sm text-gray-500 mt-1">Reported on: {notification.date}</div>
                          <div className="flex gap-2 mt-3">
                            <Button size="sm" variant="outline" onClick={() => dismissNotification(notification.id)}>
                              Dismiss
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => {
                                const game = games.find((g) => g.id === notification.gameId)
                                if (game) {
                                  deleteGame(game.id)
                                  dismissNotification(notification.id)
                                }
                              }}
                            >
                              Remove Game
                            </Button>
                          </div>
                        </div>
                      ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">No active reports</div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Thank You List Tab */}
          <TabsContent value="thank-you-list" className="space-y-6">
            {sessionStorage.getItem("isMasterAdmin") === "true" ? (
              <>
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-[#4169e1]">Thank You Messages</h2>
                  <Button
                    onClick={() => setAddThankYouFormVisible(!addThankYouFormVisible)}
                    className="bg-[#32cd32] hover:bg-[#228b22]"
                  >
                    {addThankYouFormVisible ? <X className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
                    {addThankYouFormVisible ? "Cancel" : "Add Message"}
                  </Button>
                </div>

                {addThankYouFormVisible && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Add New Thank You Message</CardTitle>
                      <CardDescription>These messages will be displayed on the Thank You page</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Name:</label>
                          <Input
                            value={newThankYou.name}
                            onChange={(e) => setNewThankYou({ ...newThankYou, name: e.target.value })}
                            placeholder="Enter person's name"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">Thank You Message:</label>
                          <Textarea
                            value={newThankYou.message}
                            onChange={(e) => setNewThankYou({ ...newThankYou, message: e.target.value })}
                            placeholder="Write a thank you message"
                            rows={3}
                          />
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-end space-x-2">
                      <Button onClick={addThankYouMessage} className="bg-[#32cd32] hover:bg-[#228b22]">
                        Add Message
                      </Button>
                    </CardFooter>
                  </Card>
                )}

                <Card>
                  <CardHeader>
                    <CardTitle>Thank You Messages List</CardTitle>
                    <CardDescription>These messages are displayed on the Thank You page</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {thankYouMessages.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Message</TableHead>
                            <TableHead>Date Added</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {thankYouMessages.map((message) => (
                            <TableRow key={message.id}>
                              <TableCell className="font-medium">{message.name}</TableCell>
                              <TableCell>{message.message}</TableCell>
                              <TableCell className="text-sm text-muted-foreground">{message.date}</TableCell>
                              <TableCell>
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => deleteThankYouMessage(message.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-center py-4 text-muted-foreground">No thank you messages added yet</div>
                    )}
                  </CardContent>
                </Card>
              </>
            ) : (
              <div className="text-center py-12 bg-white rounded-lg shadow">
                <p className="text-xl text-red-500">Access Denied</p>
                <p className="text-gray-500 mt-2">Only the master administrator can access this section.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      <footer className="bg-[#4169e1] text-white text-center p-4 mt-8 border-t-8 border-[#ffd700]">
        <p>© {new Date().getFullYear()} School Fun Games | Created for educational purposes</p>
      </footer>
    </div>
  )
}

