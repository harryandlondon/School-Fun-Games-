"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, ThumbsUp, Award, Gift, ArrowLeft } from "lucide-react"
import confetti from "canvas-confetti"

export default function ThankYouPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    // Check if user is authenticated as master admin
    const isAuth = sessionStorage.getItem("isAuthenticated")
    const isMasterAdmin = sessionStorage.getItem("isMasterAdmin")

    if (isAuth && isMasterAdmin === "true") {
      setIsAuthenticated(true)
      // Trigger confetti when the page loads
      triggerConfetti()
    } else {
      router.push("/")
    }
  }, [router])

  const triggerConfetti = () => {
    const duration = 5 * 1000
    const animationEnd = Date.now() + duration
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 }

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min
    }

    const interval: any = setInterval(() => {
      const timeLeft = animationEnd - Date.now()

      if (timeLeft <= 0) {
        return clearInterval(interval)
      }

      const particleCount = 50 * (timeLeft / duration)

      // since particles fall down, start a bit higher than random
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
      })
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
      })
    }, 250)
  }

  if (!isAuthenticated) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-purple-100 py-12 px-4">
      <div className="container mx-auto max-w-4xl">
        <Button variant="outline" onClick={() => router.push("/admin")} className="mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Admin Dashboard
        </Button>

        <Card className="border-4 border-[#ffd700] shadow-xl">
          <CardHeader className="text-center bg-[#4169e1] text-white rounded-t-lg">
            <CardTitle className="text-3xl md:text-4xl font-bold">Thank You for Your Hard Work!</CardTitle>
            <CardDescription className="text-white/90 text-lg">
              A special message for our amazing administrator
            </CardDescription>
          </CardHeader>
          <CardContent className="p-8 space-y-8">
            <div className="flex justify-center mb-6">
              <div className="flex space-x-4">
                <Heart className="h-12 w-12 text-red-500" />
                <Award className="h-12 w-12 text-[#ffd700]" />
                <ThumbsUp className="h-12 w-12 text-green-500" />
                <Gift className="h-12 w-12 text-purple-500" />
              </div>
            </div>

            <div className="prose prose-lg max-w-none text-center">
              <p className="text-xl">
                We want to express our sincere gratitude for your dedication to managing the School Fun Games platform.
              </p>

              <p className="text-lg">
                Your commitment to providing educational games and maintaining a safe environment for our students is
                truly appreciated.
              </p>

              <div className="my-8 p-6 bg-yellow-50 rounded-lg border-2 border-[#ffd700]">
                <h3 className="text-2xl font-bold text-[#4169e1] mb-4">Your Impact</h3>
                <ul className="text-left list-disc pl-6 space-y-2">
                  <li>Creating a fun learning environment for students</li>
                  <li>Managing employee access securely</li>
                  <li>Curating quality educational content</li>
                  <li>Responding promptly to reported issues</li>
                  <li>Continuously improving the platform</li>
                </ul>
              </div>

              <p className="text-xl font-bold text-[#4169e1]">Thank you for being an exceptional administrator!</p>

              <p className="text-sm text-gray-500 mt-8">
                This special message is only visible to the master administrator.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

